<!DOCTYPE html>
<html lang="ko">
<head>
<title>다음 지도 API 연동 채팅방(Ajax)</title>
<meta charset="utf-8">
<script type="text/javascript" src="chat.js"></script>
<script
	src="//dapi.kakao.com/v2/maps/sdk.js?appkey=b5424b33e65d237eaeff573d52e5d018"></script>
<link rel="stylesheet" type="text/css" href="chat.css" />
</head>
<body>
<dl id="list"></dl>
<form onsubmit="showChat(); return false;">
	<input name="umsg" id="umsg" type="text" />
	<input name="btn" id="btn" type="submit" value="입력" />
</form>
</body>
</html>