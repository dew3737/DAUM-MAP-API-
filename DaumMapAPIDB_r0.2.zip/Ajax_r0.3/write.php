<?php

$host = 'localhost';
$user = 'dew3737';
$pw = 'sls0318';
$dbName = 'dew3737';

$mysqli = new mysqli($host, $user, $pw, $dbName);

//'user'table�� msg �Է�
$msg = $_GET['msg'];

$sql = "INSERT INTO user(msg)";
$sql = $sql."VALUES('$msg')";
if($mysqli->query($sql)){
    echo $msg.'</br>';
}

?>