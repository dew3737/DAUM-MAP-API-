<html>
<head>
<title>||엘리먼트 사용하기||</title>
</head>

<script type="text/javascript">
var my_div = null;
var newDiv = null;

function addElement()
{
  // 새로운 div 엘리먼트를 만들고
  // 내용을 작성합니다.
  newDiv = document.createElement("div");
  newDiv.innerHTML = "<h1>안녕! 반가워!</h1>";

  // 생성된 엘리먼트를 추가합니다.
  my_div = document.getElementById("org_div1");
  document.body.insertBefore(newDiv, my_div);
}

</script>

<body onload="addElement()">
<div id='org_div1'> 위의 문장은 동적으로 만들어 진 것입니다.</div>
</body>
</html>