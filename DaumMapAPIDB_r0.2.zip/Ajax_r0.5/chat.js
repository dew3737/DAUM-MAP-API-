var cntMap=0;	//cntMap 초기화

function showChat(){

	//채팅내용 보여주기
	var str;
	var mapId;

	mapId = "mapId" + cntMap;
	cntMap++;

	str = document.getElementById("umsg").value;

	if(str.length == 0){
		return;
	} else {
		appendMsg(str);

		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function(){
			if(this.readyState == 4 && this.status == 200){
				var str_command = is_command(this.responseText); console.log(this.responseText);
				if (str_command == false) {
					appendMsg("response] " + this.responseText);
				} else{
					appendMap(mapId, str_command);
					console.log(mapId); 
					console.log(str_command);
					showMap(mapId);
				}
			} 

		}

		xmlhttp.open("GET", "write.php?msg="+ str, true);
		xmlhttp.send();

	}

}

//채팅 내용 append 처리
var appendMsg = function(str) {
	var cList = document.createElement("LI");	//First create an LI node,
	var cMsg = document.createElement('div');	//then create a Text node,

	cMsg.innerHTML = str;	//then append the Text node to the LI node.

	cList.appendChild(cMsg); console.log(cMsg);
	document.getElementById("list").appendChild(cList);
	
}

//map append 처리
var appendMap = function(mapId, str_command) {
	var cList = document.createElement("LI");	//First create an LI node,
	var cMap = document.createElement('div');

	cMap.id = mapId;	/*<div id="map" style="width: 400px; height: 200px;"></div>*/
	cMap.style.width = "500px";
	cMap.style.height = "400px";

	cList.appendChild(cMap); console.log(cMap);
	document.getElementById("list").appendChild(cList);
	
	//지도 생성
	var mapContainer = document.getElementById(mapId); // 지도를 표시할 div 
	
	if(str_command == '서울특별시청'){
		latLng(37.56682, 126.97865, mapContainer);
		
	} else if(str_command == '회사'){		
		latLng(37.5002020, 126.9996130, mapContainer);

	} else if(str_command == '맛집'){
		latLng(37.5049140, 127.0049150, mapContainer);
	}
}

var is_command = function(str){
	if (str == '서울특별시청' || str == '회사' || str == '맛집'){
		return str;
	} else {
		return false;
	}
}

function latLng(val1, val2, mapContainer){
	
	var mapOption = {
			center: new daum.maps.LatLng(val1, val2), // 지도의 중심좌표
			level: 3, // 지도의 확대 레벨
			mapTypeId : daum.maps.MapTypeId.ROADMAP // 지도종류
	}; 

	//	지도를 생성한다 
	var map = new daum.maps.Map(mapContainer, mapOption); 

	//	지도에 마커를 생성하고 표시한다
	var marker = new daum.maps.Marker({
		position: new daum.maps.LatLng(val1, val2), // 마커의 좌표
		map: map // 마커를 표시할 지도 객체
	});
}

