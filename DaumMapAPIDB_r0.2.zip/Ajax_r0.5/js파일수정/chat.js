var cntMap=0;	//cntMap 초기화

function showChat(){

	//채팅내용 보여주기
	var str;
	var mapId;

	mapId = "mapId" + cntMap;
	cntMap++;

	str = document.getElementById("umsg").value;

	if(str.length == 0){
		return;
	} else {
		appendMsg(str);

		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function(){
			if(this.readyState == 4 && this.status == 200){
				var str_command = is_command(this.responseText); console.log(this.responseText);
				if (str_command == false) {
					appendMsg("response] " + this.responseText);
				} else{
					appendMap(mapId, str_command);
					console.log(mapId); 
					console.log(str_command);
					showMap(str_command);
				}
			} 

		}

		xmlhttp.open("GET", "write.php?msg="+ str, true);
		xmlhttp.send();

	}

}

//채팅 내용 append 처리
var appendMsg = function(str) {
	var cList = document.createElement("LI");	//First create an LI node,
	var cMsg = document.createElement('div');	//then create a Text node,

	cMsg.innerHTML = str;	//then append the Text node to the LI node.

	cList.appendChild(cMsg); console.log(cMsg);
	document.getElementById("list").appendChild(cList);
	
}

//map append 처리
var appendMap = function(mapId, str_command) {
	var cList = document.createElement("LI");	//First create an LI node,
	var cMap = document.createElement('div');

	cMap.id = mapId;	/*<div id="map" style="width: 400px; height: 200px;"></div>*/
	cMap.style.width = "500px";
	cMap.style.height = "400px";

	cList.appendChild(cMap); console.log(cMap);
	document.getElementById("list").appendChild(cList);
	
	//지도 생성
	var mapContainer = document.getElementById(mapId); // 지도를 표시할 div 

	if(str_command == '서울특별시청'){
		var mapOption = {
				center: new daum.maps.LatLng(37.56682, 126.97865), // 지도의 중심좌표
				level: 3, // 지도의 확대 레벨
				mapTypeId : daum.maps.MapTypeId.ROADMAP // 지도종류
		}; 

		//	지도를 생성한다 
		var map = new daum.maps.Map(mapContainer, mapOption); 

		//	지도에 마커를 생성하고 표시한다
		var marker = new daum.maps.Marker({
			position: new daum.maps.LatLng(37.56682, 126.97865), // 마커의 좌표
			map: map // 마커를 표시할 지도 객체
		});
	} else if(str_command == '회사'){
		var mapOption = {
				center: new daum.maps.LatLng(37.5002020, 126.9996130), // 지도의 중심좌표
				level: 3, // 지도의 확대 레벨
				mapTypeId : daum.maps.MapTypeId.ROADMAP // 지도종류
		}; 

		// 지도를 생성한다 
		var map = new daum.maps.Map(mapContainer, mapOption); 

		// 지도에 마커를 생성하고 표시한다
		var marker = new daum.maps.Marker({
			position: new daum.maps.LatLng(37.5002020, 126.9996130), // 마커의 좌표
			map: map // 마커를 표시할 지도 객체
		});

		// 인포윈도우로 장소에 대한 설명을 표시합니다
		var infowindow = new daum.maps.InfoWindow({
			content: '<div style="width:150px;text-align:center;padding:6px 0;">LMFriends</div>'
		});
		infowindow.open(map, marker);
	} else if(str_command == '맛집'){
		var mapOption = {
				center: new daum.maps.LatLng(37.5049140, 127.0049150), // 지도의 중심좌표
				level: 3, // 지도의 확대 레벨
				mapTypeId : daum.maps.MapTypeId.ROADMAP // 지도종류
		}; 

		// 지도를 생성한다 
		var map = new daum.maps.Map(mapContainer, mapOption); 

		// 마커를 표시할 위치와 내용을 가지고 있는 객체 배열입니다 
		var positions = [
			{
				content: '<div>피자헛</div>', 
				latlng: new daum.maps.LatLng(37.5046544, 127.0043061)
			},
			{
				content: '<div>KFC</div>', 
				latlng: new daum.maps.LatLng(37.5064588, 127.0046924)
			}
			];

		for (var i = 0; i < positions.length; i ++) {
			// 마커를 생성합니다
			var marker = new daum.maps.Marker({
				map: map, // 마커를 표시할 지도
				position: positions[i].latlng // 마커의 위치
			});

			// 마커에 표시할 인포윈도우를 생성합니다 
			var infowindow = new daum.maps.InfoWindow({
				content: positions[i].content // 인포윈도우에 표시할 내용
			});

			// 마커에 mouseover 이벤트와 mouseout 이벤트를 등록합니다
			// 이벤트 리스너로는 클로저를 만들어 등록합니다 
			// for문에서 클로저를 만들어 주지 않으면 마지막 마커에만 이벤트가 등록됩니다
			daum.maps.event.addListener(marker, 'mouseover', makeOverListener(map, marker, infowindow));
			daum.maps.event.addListener(marker, 'mouseout', makeOutListener(infowindow));
		}

		// 인포윈도우를 표시하는 클로저를 만드는 함수입니다 
		function makeOverListener(map, marker, infowindow) {
			return function() {
				infowindow.open(map, marker);
			};
		}

		// 인포윈도우를 닫는 클로저를 만드는 함수입니다 
		function makeOutListener(infowindow) {
			return function() {
				infowindow.close();
			};
		}
	}

}

var is_command = function(str){
	if (str == '서울특별시청' || str == '회사' || str == '맛집'){
		return str;
	} else {
		return false;
	}
}
