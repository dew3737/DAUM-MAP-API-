function showChat(){

	//채팅내용 보여주기
	var str;
	str = document.getElementById("umsg").value; console.log(str);
	document.getElementById("list").innerHTML + str;

	if(str.length == 0){
		return;
	} else {
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function(){
			if(this.readyState == 4 && this.status == 200){ console.log("good");
			document.getElementById("list").innerHTML = document.getElementById("list").innerHTML + this.responseText;
			console.log(this.responseText);
			}
		}

		xmlhttp.open("GET", "write.php?msg="+ str, true);
		xmlhttp.send(); console.log(str);

	}

	//서울특별시청 map
	var mapContainer = document.getElementById('map'), // 지도를 표시할 div 
	mapOption = {
		center: new daum.maps.LatLng(37.56682, 126.97865), // 지도의 중심좌표
		level: 3, // 지도의 확대 레벨
		mapTypeId : daum.maps.MapTypeId.ROADMAP // 지도종류
	}; 

	//	지도를 생성한다 
	var map = new daum.maps.Map(mapContainer, mapOption); 

	//	지도에 마커를 생성하고 표시한다
	var marker = new daum.maps.Marker({
		position: new daum.maps.LatLng(37.56682, 126.97865), // 마커의 좌표
		map: map // 마커를 표시할 지도 객체
	});

}
