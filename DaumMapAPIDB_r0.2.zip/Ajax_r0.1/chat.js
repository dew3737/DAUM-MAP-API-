function showChat(){
	
	//채팅내용 보여주기
	var str;
	str = document.getElementById("umsg").value; console.log(str);
	document.getElementById("list").innerHTML = document.getElementById("list").innerHTML + str; console.log(str); 

	if(str.length == 0){
		return;
	} else {
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function(){
			if(this.readyState == 4 && this.status == 200){ console.log("good");
				document.getElementById("list").innerHTML = document.getElementById("list").innerHTML + this.responseText;
				console.log(this.responseText);
				console.log(this.showMap1); //undefined
			}
		}
		
		xmlhttp.open("GET", "write.php?msg="+ str, true);
		xmlhttp.send(); console.log(str);
		
	}
}